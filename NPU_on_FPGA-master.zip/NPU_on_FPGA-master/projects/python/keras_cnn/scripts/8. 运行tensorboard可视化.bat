cd ..
tensorboard --logdir=.\logs